const apiKey = "fb2ddd33e1958829ee86fcd1c93e9fe3";  
const searchBtn = document.getElementById('searchBtn');
const cityInput = document.getElementById('cityInput');
const errorMessage = document.getElementById('errorMessage');
const currentWeather = document.getElementById('currentWeather');
const extendedForecast = document.getElementById('extendedForecast');
const cityHistory = document.getElementById('cityHistory');

let recentCities = JSON.parse(localStorage.getItem("recentCities")) || [];

function getWeather(city) {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;
    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.cod === 200) {
                displayWeather(data);
                saveToHistory(city);
                getExtendedForecast(data.coord.lat, data.coord.lon);
            } else {
                errorMessage.classList.remove("hidden");
            }
        })
        .catch(error => {
            errorMessage.classList.remove("hidden");
        });
}

function displayWeather(data) {
    document.getElementById('cityName').innerText = `${data.name}, ${data.sys.country}`;
    document.getElementById('temp').innerText = `Temperature: ${data.main.temp}°C`;
    document.getElementById('wind').innerText = `Wind Speed: ${data.wind.speed} km/h`;
    document.getElementById('humidity').innerText = `Humidity: ${data.main.humidity}%`;
    document.getElementById('weatherIcon').src = `https://openweathermap.org/img/wn/${data.weather[0].icon}.png`;
    currentWeather.classList.remove('hidden');
    errorMessage.classList.add('hidden');
}

function getExtendedForecast(lat, lon) {
    const url = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
    fetch(url)
        .then(response => response.json())
        .then(data => {
            displayExtendedForecast(data.list);
        })
        .catch(error => console.error("Error fetching extended forecast:", error));
}

function displayExtendedForecast(forecast) {
    extendedForecast.innerHTML = '';
    forecast.forEach(item => {
        if (item.dt_txt.includes("12:00:00")) {  // Filter for midday forecasts
            const forecastElement = document.createElement('div');
            forecastElement.classList.add('bg-blue-100', 'p-4', 'rounded-lg', 'text-center');
            const date = new Date(item.dt * 1000);
            forecastElement.innerHTML = `
                <h3 class="font-bold">${date.toLocaleDateString()}</h3>
                <img src="https://openweathermap.org/img/wn/${item.weather[0].icon}.png" class="mx-auto w-12 h-12">
                <p>Temp: ${item.main.temp}°C</p>
                <p>Wind: ${item.wind.speed} km/h</p>
                <p>Humidity: ${item.main.humidity}%</p>
            `;
            extendedForecast.appendChild(forecastElement);
        }
    });
    extendedForecast.classList.remove('hidden');
}

function saveToHistory(city) {
    if (!recentCities.includes(city)) {
        recentCities.push(city);
        if (recentCities.length > 5) {
            recentCities.shift();  // Keep only the last 5 cities
        }
        localStorage.setItem("recentCities", JSON.stringify(recentCities));
        updateCityHistory();
    }
}

function updateCityHistory() {
    cityHistory.innerHTML = '<option value="">Select recently searched city</option>';
    recentCities.forEach(city => {
        const option = document.createElement('option');
        option.value = city;
        option.innerText = city;
        cityHistory.appendChild(option);
    });
}

function getWeatherFromCoords() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            const lat = position.coords.latitude;
            const lon = position.coords.longitude;
            getWeatherByCoords(lat, lon);
        });
    }
}

function getWeatherByCoords(lat, lon) {
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
    fetch(url)
        .then(response => response.json())
        .then(data => {
            displayWeather(data);
            getExtendedForecast(lat, lon);
        })
        .catch(error => console.error("Error fetching weather by coordinates:", error));
}

searchBtn.addEventListener('click', () => {
    const city = cityInput.value.trim();
    if (city) {
        getWeather(city);
        cityInput.value = '';
    }
});

cityHistory.addEventListener('change', (event) => {
    const selectedCity = event.target.value;
    if (selectedCity) {
        getWeather(selectedCity);
    }
});

// Initial setup: check if there are any recent cities in localStorage
updateCityHistory();
getWeatherFromCoords();
